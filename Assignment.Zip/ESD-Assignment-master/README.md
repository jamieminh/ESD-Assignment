# ESD-Assignment
Assignment for ESD

## Group: 26. Members includes
1. Au Dam     - 18032351
2. Bao Bui	  - 19034799
3. Biao Shen  - 18041925
4. Hue Nguyen - 19035298
5. Phong Phan - 19036141



## How to use
1. Create a Java DB called 'assignment', with username='root', password='root'.    
2. Choose 'APP' as the default schema.
3. Run the SmartCare_new.sql script to create tables and populate some sample data.
4. Add the 'json-simple-1.1.1.jar' file to libraries folder by right-click Libraries folder in project window -> Add JAR/Folder


## Login: use one of the following login info to get started
1. Admin: username = 'hue' ; password = 'nguyen'
2. Client: username = 'phong' ; password = 'phan'
3. Doctor: username = 'biao' ; password = 'shen'
4. Nurse: username = 'au' ; password = 'dam'
