/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.util.ArrayList;
import model.dbHandler.DBBean;
import model.pojo.Client;
import model.pojo.Employee;
import model.pojo.Operation;

/**
 *
 * @author 14736
 */
public class PrescriptionDao extends DAO {

    public PrescriptionDao(Connection con) {
        super(con);
    }

    private DBBean db = this.getDb();
    private Connection con = this.getCon();

    public ArrayList<Operation> getAllSchedule() {
        String[][] result = db.getAllRecords("prescription");
        ArrayList<Operation> schedule = new ArrayList<Operation>();

        EmployeeDao employeeDao = new EmployeeDao(con);
        ClientDAO clientDao = new ClientDAO(con);

        for (String[] res : result) {
            Operation op = new Operation();
            Employee emp = employeeDao.getEmpNameById(Integer.parseInt(res[1]));
            Client client = clientDao.getClientNameById(Integer.parseInt(res[2]));

            op.setId(Integer.parseInt(res[0]));
            op.setEmployee(emp);
            op.setClient(client);
            op.setType(res[5]);
            op.setDate(res[3]);
            op.setTime(res[4]);

            schedule.add(op);
        }

        return schedule;

    }

    public ArrayList<Operation> getScheduleByEmpId(int empId) {
        ArrayList<Operation> schedule = new ArrayList<Operation>();
        
        String query = "SELECT * FROM APP.PRESCRIPTION WHERE eid=" + empId;
        String[][] result = db.getRecords(query);

        EmployeeDao employeeDao = new EmployeeDao(con);
        ClientDAO clientDao = new ClientDAO(con);

        for (String[] res : result) {
            Operation op = new Operation();
            Employee emp = employeeDao.getEmpNameById(Integer.parseInt(res[1]));
            Client client = clientDao.getClientNameById(Integer.parseInt(res[2]));

            op.setId(Integer.parseInt(res[0]));
            op.setEmployee(emp);
            op.setClient(client);
            op.setType(res[5]);
            op.setDate(res[3]);
            op.setTime(res[4]);
            schedule.add(op);
        }

        return schedule;
    }
    
    public ArrayList<Operation> getScheduleById(int scheduleId) {
        ArrayList<Operation> schedule = new ArrayList<Operation>();
        
        String query = "SELECT * FROM APP.PRESCRIPTION WHERE sid=" + scheduleId;
        String[][] result = db.getRecords(query);

        EmployeeDao employeeDao = new EmployeeDao(con);
        ClientDAO clientDao = new ClientDAO(con);

        for (String[] res : result) {
            Operation op = new Operation();
            Employee emp = employeeDao.getEmpNameById(Integer.parseInt(res[1]));
            Client client = clientDao.getClientNameById(Integer.parseInt(res[2]));

            op.setId(Integer.parseInt(res[0]));
            op.setEmployee(emp);
            op.setClient(client);
            op.setPreDescription(res[5]);
            op.setDate(res[3]);
            op.setUseTime(res[4]);
            schedule.add(op);
        }

        return schedule;
    }
    public boolean updatePre ( int cId, String date, int puse, String PreDescription){
        String query = String.format("UPDATE APP.PRESCRIPTION SET PDATE='%s', PUSE='%s',PDESCRIPTION='%s' where CID =%s ", date,puse,PreDescription,cId);
        boolean res = db.executeUpdate(query);
        return res;
    }  
    
    public boolean addSurgeries(int empId, int patId, String date, String time, String PreDescription) {
        String query = String.format("INSERT INTO APP.PRESCRIPTION (eid, cid, pdate, puse, pdescription) "
                + " VALUES(%s, %s, '%s', '%s', '%s')", empId, patId, date, time, PreDescription);
        
        boolean res = db.executeUpdate(query);
        
        if (res) {
            double charge = 1000 + Math.random() * (5000 - 1000);
            
            String query2 =  String.format("SELECT sid FROM APP.PRESCRIPTION WHERE"
                    + " eid=%s AND cid=%s AND pdate='%s' AND puse='%s'AND pdescription='%s'", empId, patId, date, time, PreDescription);
            String sid = db.getRecords(query2)[0][0];
            
            BillingDao billingDao = new BillingDao(con);
            res = billingDao.insertBilling(Integer.parseInt(sid), (float) Math.round(charge * 100.0 / 100.0));            
        }
        
        return res;
        
    }

    public boolean cancelSchedule(String sid ) {
        String query = "UPDATE APP.PRESCRIPTION SET cancelled='true' WHERE sid=" + sid;
        return db.executeUpdate(query);
    }

}
