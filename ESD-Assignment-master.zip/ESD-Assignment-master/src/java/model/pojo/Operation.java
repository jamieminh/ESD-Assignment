/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.pojo;

import java.util.Date;

/**
 *
 * @author Jamie
 */
public class Operation {
    private int id;
    private Employee employee;
    private Client client;
    private String date;
    private String time;
    private String type;
    private int nSlot;
    private String Usetime;
    private String PreDescription;
    private boolean isCancelled;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getnSlot() {
        return nSlot;
    }

    public void setnSlot(int nSlot) {
        this.nSlot = nSlot;
    }
    public String getUseTime() {
        return Usetime;
    }

    public void setUseTime(String Usetime) {
        this.Usetime = Usetime;
    }

    public String getPreDescription() {
        return PreDescription;
    }

    public void setPreDescription(String PreDescription) {
        this.PreDescription = PreDescription;
    }

    public boolean isIsCancelled() {
        return isCancelled;
    }

    public void setIsCancelled(boolean isCancelled) {
        this.isCancelled = isCancelled;
    }
    
    
}
